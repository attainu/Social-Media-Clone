// import {createStore , applyMiddleware,compose} from "redux";
// import thunk from "redux-thunk";
// import rootReducer from "./redux/reducer/rootReducer";
// import {reduxFirestore, getFirestore,createFirestoreInstance} from "redux-firestore";
// import {ReactReduxFirebaseProvider,getFirebase} from "react-redux-firebase";
// import firebaseConfig from "./firebase";
// import firebase from "firebase"



// const store = createStore(rootReducer,compose(thunk.withExtraArgument({getFirestore,reduxFirestore(firebaseConfig)})) 
// )

// const rrfprops = {
//     firebase,
//     config: firebaseConfig,
//     dispatch:store.dispatch,
//     createFirestoreInstance
// }

// export default store;